﻿$text = 'Hello World'

# Create file:

$text | Set-Content 'c:\windows\temp\file.txt'


